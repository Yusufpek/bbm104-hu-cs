public interface ICommand {
    String convertBinary(String value);

    String countBinary(String value);

    String checkPalindrome(String value);

    String checkExpression(String value);
}

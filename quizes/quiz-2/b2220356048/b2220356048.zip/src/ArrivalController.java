public interface ArrivalController {
    public void ArrivalSchedule(TripSchedule tripSchedule);
}

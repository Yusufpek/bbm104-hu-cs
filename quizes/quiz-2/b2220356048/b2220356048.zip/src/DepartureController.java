public interface DepartureController {
    public void DepartureSchedule(TripSchedule tripSchedule);
}

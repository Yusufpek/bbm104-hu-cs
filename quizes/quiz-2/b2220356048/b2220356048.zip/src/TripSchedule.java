public class TripSchedule {
    public Trip[] trips;

    TripSchedule(Trip[] tripList) {
        this.trips = tripList;
    }
}

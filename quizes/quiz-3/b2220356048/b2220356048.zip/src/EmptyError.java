public class EmptyError extends Exception {
    EmptyError() {
        super(Messages.EMPTY_ERROR);
    }
}

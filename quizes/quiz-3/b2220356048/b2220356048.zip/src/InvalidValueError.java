public class InvalidValueError extends Exception {
    InvalidValueError() {
        super(Messages.INVALID_CHAR_ERROR);
    }
}

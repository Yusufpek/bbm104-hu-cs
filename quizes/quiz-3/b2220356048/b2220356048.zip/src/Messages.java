class Messages {
    static final String NO_ERROR = "The program is running correctly";
    static final String PARAMETER_ERROR = "There should be only 1 paremeter";
    static final String EMPTY_ERROR = "The input file should not be empty";
    static final String INVALID_CHAR_ERROR = "The input file should not contains unexpected characters";
    static final String INPUT_NOT_FOUND_ERROR = "There should be an input file in the specified path";
}

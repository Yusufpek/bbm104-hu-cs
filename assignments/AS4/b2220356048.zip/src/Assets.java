/**
 * An abstract class representing assets used in the Duck Hunt game.
 */
public abstract class Assets {

    static final protected String BASE = "assets/";
    static protected String TYPE;
}